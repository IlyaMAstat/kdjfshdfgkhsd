﻿using Case3WPF.Scripts;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Case3WPF
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            var httpWebRequest = (HttpWebRequest)WebRequest.Create($"https://localhost:44348/api/CaseTbls?email=markinia@gmail.com&password=123456");

            httpWebRequest.ContentType = "text/json";
            httpWebRequest.Method = "GET";//Можно GET
            httpWebRequest.ContentLength = 0;
            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            User res= new User();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                //ответ от сервера
                var result = streamReader.ReadToEnd(); 

                //using (StreamWriter writer = new StreamWriter("sad.json"))
                //{
                //    writer.WriteLine(result);
                //}
                //Сериализация
               res = JsonConvert.DeserializeObject<User>(result);
                    MessageBox.Show($"{res.FIO}");
            }
        }
    }
}
